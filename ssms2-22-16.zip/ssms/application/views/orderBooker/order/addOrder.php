<?php include_once(APPPATH.'views/orderBooker/_header.php'); ?>


</head>

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  
  <?php include_once(APPPATH.'views/orderBooker/top_menu.php'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once(APPPATH.'views/orderBooker/left_menu.php'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Order </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order</a></li>
        <li class="active">Add</li>
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content"> 
      
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
        <!--    <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset>
          <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset> -->
            <div class="col-md-6">
              
              
              <div class="form-group">
                <label>Select Product</label>
                <select class="form-control">
                <option>option 1</option>
                <option>option 2</option>
                <option>option 3</option>
                <option>option 4</option>
                <option>option 5</option>
                </select>
                </div>
             	
                <!-- /.form-group -->
              <div class="form-group">
                <label>Product Size</label>
                <select class="form-control">
                <option>option 1</option>
                <option>option 2</option>
                <option>option 3</option>
                <option>option 4</option>
                <option>option 5</option>
                </select>
                </div>
             
              <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" rows="3" placeholder="Product Description"></textarea>
              </div>
              
               <div class="form-group">
                <label>Delivery Address</label>
                <textarea class="form-control" rows="3" placeholder="Delivery Address"></textarea>
              </div>
              
              
              
              <div class="box-footer">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
              
            </div>
            <!-- /.col -->
            <div class="col-md-6">
              
              <div class="form-group">
                <label>Price</label>
                <input type="text" class="form-control" placeholder="Selling Price">
              </div>
              
              <div class="form-group">
                <label>Product Weight</label>
                <input type="text" class="form-control" placeholder="Product Weight">
              </div>
              
              <div class="form-group">
                    <label>Date range:</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                      <input class="form-control pull-right" id="reservation" type="text">
                    </div><!-- /.input group -->
                  </div>
                  
                  <div class="form-group">
                <label for="exampleInputFile">Product Image</label>
                  
              </div>
                  
                  
       
              
              
              <!-- /.form-group --> 
            </div>
            <!-- /.col --> 
          </div>
          <!-- /.row --> 
        </div>
        <!-- /.box-body -->
        
      <!-- /.box -->
      
      
      <!-- /.row --> 
      
    </section>
    <!-- /.content --> 
  </div>
  <!-- /.content-wrapper -->
 


<?php include_once(APPPATH.'views/orderBooker/_footer.php'); ?>
