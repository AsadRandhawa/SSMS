<?php include_once(APPPATH.'views/admin/_header.php'); ?>


</head>

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  
  <?php include_once(APPPATH.'views/admin/top_menu.php'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once(APPPATH.'views/admin/left_menu.php'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add User </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User Management</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content"> 
      
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
        <!--    <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset>
          <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset> -->
            <div class="col-md-6">
              
               <div class="form-group has-feedback">
                <label>First Name</label>
                <input class="form-control" type="text" placeholder="First name">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                
                <div class="form-group has-feedback">
                <label>Last Name</label>
                <input class="form-control" type="text" placeholder="Last name">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                
              <div class="form-group">
                <label>User Type</label>
                <select class="form-control">
                <option>Sale man</option>
                <option>distributer</option>
                </select>
                </div>
             	
               
                  
             
              <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" rows="3" placeholder="User Address"></textarea>
              </div>
              
              <div class="form-group">
                <label for="exampleInputFile">User Image</label>
                  <input type="file" id="exampleInputFile">
                  <p class="help-block">Only jpg, png, gif are allowed.</p>

              </div>
              
              <div class="box-footer">
                <button class="btn btn-primary" type="submit">Submit</button>
              </div>
              
            </div>
            <!-- /.col -->
            <div class="col-md-6">
            
             <div class="form-group has-feedback">
             <label>Email</label>
            <input class="form-control" type="email" placeholder="Email">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>
            
             <div class="form-group has-feedback">
             <label>Password</label>
            <input class="form-control" type="password" placeholder="Password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            
             <div class="form-group has-feedback">
             <label>Retype Password</label>
            <input class="form-control" type="password" placeholder="Retype password">
            <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
            </div>
            
              <div class="form-group">
                <label>CNIC</label>
                <input type="text" class="form-control" placeholder="CNIC">
              </div>
              
               <!-- /.form-group -->
               <div class="form-group">
                    <label>Phone No:</label>
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-phone"></i>
                      </div>
                      <input type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask>
                    </div>
                    </div> 
                    <!-- /.input group -->
              
             
              
              <!-- /.form-group --> 
            </div>
            <!-- /.col --> 
          </div>
          <!-- /.row --> 
        </div>
        <!-- /.box-body -->
        <div class="box-footer"> Visit <a href="https://select2.github.io/">Select2 documentation</a> for more examples and information about the plugin. </div>
      </div>
      <!-- /.box -->
      
      
      <!-- /.row --> 
      
    </section>
    <!-- /.content --> 
  </div>
  <!-- /.content-wrapper -->
 


<?php include_once(APPPATH.'views/admin/_footer.php'); ?>
