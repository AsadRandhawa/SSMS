<?php include_once(APPPATH.'views/admin/_header.php'); ?>

</head>

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  
  <?php include_once(APPPATH.'views/admin/top_menu.php'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once(APPPATH.'views/admin/left_menu.php'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1> Add Product </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Products</a></li>
        <li class="active">Add</li>
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content"> 
      
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
        <!--    <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset>
          <fieldset>
          	<div class="col-lg-12">
            <div class="form-group col-lg-4"></div>
            <div class="col-lg-4 ">
            <label >test</label>
            <input type="text" class="form-control ">
            </div>
            </div>
          </fieldset> -->
            <div class="col-md-6">
			 <p><span class="error">* required field.</span></p>
           	 <?php if( isset($error)){ ?>
			  
				  <div class="alert alert-danger" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Error:</span>
				<?php  echo $error?>
				</div>
			<?php } ?>
			  
			  
			  <?php 
			  	$message = $this->session->flashdata('message');
			  	if(!empty($message)){
			  ?>
			  	<script>
			  		swal("Good job!", "Record Added", "success")
			  	</script>	
			  
				  <div class="alert alert-success" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Congratulations:</span>
					<?php  echo $message?>
					</div>
			<?php } ?>
			 
              
              
			<?php /*?><?php
                if (isset($error)){
                    echo $error;
                }
                
                
                    if (isset($data['message'])){
                     echo $data['message'];
                }
            
             ?><?php */?>
              <?php echo form_open_multipart('admin/products/add'); ?>
              <div class="form-group">
                <label>Product Name *</label>
                <input name="p_name" id="p_name" type="text" class="form-control" placeholder="Product Name" value="<?php echo set_value('p_name'); ?>">
                    <span class="error"><?php echo form_error('p_name'); ?></span>
              </div>
              
             <div class="form-group">
                <label>Select Product Category</label>
                <select class="form-control" name="p_cat">
                
                <option>Juice</option>
                <option>Carbonated</option>
                <option>Water</option>
                
                </select>
                </div>
             	
                <!-- /.form-group -->
              <div class="form-group">
                <label>Enter Product Size</label>
                <input name="p_size" id="p_size" type="text" class="form-control" placeholder="Product Size" value="<?php echo set_value('p_size'); ?>">
                    <span class="error"><?php echo form_error('p_size'); ?></span>
              </div>
             
              
              <div class="form-group">
                <label for="p_image">Product Image</label>
                  <input type="file" id="p_image" name="p_image">
                  <p class="help-block">Only jpg, png, gif are allowed.</p>

              </div>
              
              <div class="box-footer">
                <button type="submit" name="submit"  class="btn btn-success"><span class="glyphicon glyphicon-floppy-saved" aria-hidden="true"></span> Submit</button>
              </div>
              
            </div>
            <!-- /.col -->
            <div class="col-md-6">
              <div class="form-group">
                <label>Production Price</label>
                 <input name="prod_price" id="prod_price" type="text" class="form-control" placeholder="Production Price" value="<?php echo set_value('prod_price'); ?>">
                    <span class="error"><?php echo form_error('prod_price'); ?></span>
              </div>
              <div class="form-group">
                <label>Sale Price</label>
                <input name="sale_price" id="sale_price" type="text" class="form-control" placeholder="Sale Price" value="<?php echo set_value('sale_price'); ?>">
                    <span class="error"><?php echo form_error('sale_price'); ?></span>
              </div>
              
              <div class="form-group">
                <label>Product Weight</label>
                 <input name="p_weight" id="p_weight" type="text" class="form-control" placeholder="Product Weight" value="<?php echo set_value('p_weight'); ?>">
                    <span class="error"><?php echo form_error('p_weight'); ?></span>
              </div>
             
              <!-- /.form-group --> 
            
           
            <!-- /.col --> 
          </div> 
		  <?php echo form_close(); ?>
          <!-- /.row --> 
        </div>
        <!-- /.box-body -->
        <div class="box-footer">  </div>
      </div>
      <!-- /.box -->
      
      
      <!-- /.row --> 
      
    </section>
    <!-- /.content --> 
  </div>
  <!-- /.content-wrapper -->
 


<?php include_once(APPPATH.'views/admin/_footer.php'); ?>
