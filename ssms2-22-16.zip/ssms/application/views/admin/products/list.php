<?php include_once(APPPATH.'views/admin/_header.php'); ?>

    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url("assets/admin/plugins/datatables/dataTables.bootstrap.css") ?>">
    
</head>

<body class="hold-transition skin-blue sidebar-mini">

<div class="wrapper">
  
  <?php include_once(APPPATH.'views/admin/top_menu.php'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once(APPPATH.'views/admin/left_menu.php'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            View All
            <small>Products</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Products</a></li>
            <li class="active">View All</li>
          </ol>
        </section>
        <?php if( isset($error)){ ?>
			  
				  <div class="alert alert-danger" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Error:</span>
				<?php  echo $error?>
				</div>
			<?php } ?>
			  
			  
			  <?php 
			  	$message = $this->session->flashdata('message');
			  	if(!empty($message)){
			  ?>
			  	<script>
			  		swal("Done!", "Record Updated", "success")
			  	</script>	
			  
				  <div class="alert alert-success" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Congratulations:</span>
					<?php  echo $message?>
					</div>
			<?php } ?>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data Table With Full Features</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                     	<th>Product Name</th>
                        <th>Category</th>
                        <th>Size</th>
						<th>Production Price</th>
                        <th>Sale Price</th>
                        <th>Product Weight</th>
                        <th>Product Image</th>
                        <th>Created On</th>
                        <th>Actions</th>
                       </tr>
					 </thead>
					 <tbody>
                        <?php if($products->result_id->num_rows > 0){
						
								foreach($products->result() as $u){ ?>
									<tr>
									  <th><?php echo $u->product_name; ?></th>								  
									  <th><?php echo $u->product_category; ?></th>
									  <th><?php echo $u->product_size; ?></th>
									  <th><?php echo $u->production_price; ?></th>
                                      <th><?php echo $u->sale_price; ?></th>
                                      <th><?php echo $u->product_weight; ?></th>
                                      <th><img src="<?php echo base_url() . "uploads/" . $u->product_image; ?>" width="100" /></th>
									  <th><?php echo $u->created_dtm; ?></th>
                                      <th><a href="<?php echo site_url("admin/products/edit/".$u->productID) ?>">Update</a> | <a href="<?php echo site_url("admin/products/delete/".$u->productID) ?>" onClick="return confirm('Are you sure to delete this record?')">Delete</a></th>
							  		
<?php /*?>								  <th><a href="admin/products/edit/<?php echo $u->user_id ?>">Edit</a> | <a href="admin/products/delete/<?php echo $u->user_id ?>" 					onclick="">Delete</a></th><?php */?>
									</tr>
						<?php }?>
							
						
							
						<?php		
						}else{?>
							<tr>
								<td colspan="8">No record found.</td>
							</tr>
						<?php
						} ?>
						
						
					  </tbody>
					</table>
					
             
            </div>
        </div>
            
        	
             
        </div>
        <div class="col-md-2"></div>
   		</div>  
</div>
                        

                  
                    
                  
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
  <!-- /.content-wrapper -->
 
 <!-- DataTables -->
<script src="<?php echo base_url("assets/admin/plugins/datatables/jquery.dataTables.min.js") ?>"></script>
<script src="<?php echo base_url("assets/admin/plugins/datatables/dataTables.bootstrap.min.js") ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url("assets/admin/plugins/slimScroll/jquery.slimscroll.min.js") ?>"></script>

<!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>


<?php include_once(APPPATH.'views/admin/_footer.php'); ?>
