<?php include_once(APPPATH.'views/admin/_header.php'); ?>

</head>

<body class="hold-transition skin-blue sidebar-mini">
  
  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="wrapper">
  
  <?php include_once(APPPATH.'views/admin/top_menu.php'); ?>
  
  <!-- Left side column. contains the logo and sidebar -->
  <?php include_once(APPPATH.'views/admin/left_menu.php'); ?>
  
  <section class="content-header">
      <h1> Update Product </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Products</a></li>
        <li class="active">update</li>
      </ol>
    </section>
  <section class="content"> 
      
      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
    <!-- /.col-sm-4 -->
    <div class="col-sm-6">
    	<?php if(isset($product->productID)){ ?>
    
      <?php echo form_open_multipart('admin/products/edit/'.$product->productID, array('id' => 'editproduct_form','name' => 'editproduct_form'));?>
       <?php if( isset($error)){ ?>
			  
				  <div class="alert alert-danger" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Error:</span>
				<?php  echo $error?>
				</div>
			<?php } ?>
			  
			  
			  <?php 
			  	$message = $this->session->flashdata('message');
			  	if(!empty($message)){
			  ?>
			  	<script>
			  		swal("Good job!", "Record Added", "success")
			  	</script>	
			  
				  <div class="alert alert-success" role="alert">
					  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					  <span class="sr-only">Congratulations:</span>
					<?php  echo $message?>
					</div>
			<?php } ?>

        <?php //echo validation_errors(); // to show all errors at one place ?>
        <div class="form-group">
          <label for="product_name">Product Name</label>
          <input type="text" class="form-control" id="product_name" value="<?php echo set_value("product_name",$product->product_name); ?>" name="product_name" placeholder="Product Name">
          <span class="error"><?php echo form_error("product_name"); ?></span>
        </div>
         <div class="form-group">
          <label for="product_category">Product Category</label>
          <select name="product_category" id="product_category">
          	<option value="Carbonated" <?php echo  set_select('product_category', 'Carbonated',($product->product_category=='Carbonated') ? TRUE:FALSE); ?>>Carbonated</option>
            <option value="juice" <?php echo  set_select('product_category', 'student',($product->product_category=='Juice') ? TRUE:FALSE); ?>>Juice</option>
            <option value="Water" <?php echo  set_select('product_category', 'teacher',($product->product_category=='Water') ? TRUE:FALSE); ?>>Water</option>
          </select>
          <span class="error"><?php echo form_error("product_category"); ?></span>
        </div>
        <div class="form-group">
          <label for="product_size">Product Size</label>
          <input type="text" class="form-control" id="product_size" name="product_size" value="<?php echo set_value("product_size",$product->product_size); ?>" placeholder="Product Size">
          <span class="error"><?php echo form_error("product_size"); ?></span>
        </div>
         <div class="form-group">
          <label for="product_image">Product Image</label>
          <input type="file" id="product_image" name="product_image">
          <img src="<?php echo base_url() . "uploads/" . $product->product_image; ?>" width="200" />
          <p class="help-block">Only jpg,gif and png images allowed</p>
        </div>
        
        
        </div>  
        <div class="col-md-6">
        <div class="form-group">
          <label for="production_price">Production Price</label>
          <input type="text" class="form-control" id="production_price" name="production_price" value="<?php echo set_value("production_price",$product->production_price); ?>" placeholder="Production Price">
          <span class="error"><?php echo form_error("production_price"); ?></span>
        </div>
         <div class="form-group">
          <label for="sale_price">Sale Price</label>
          <input type="text" class="form-control" id="sale_price" name="sale_price" value="<?php echo set_value("sale_price",$product->sale_price); ?>" 				placeholder="Sale Price">
          <span class="error"><?php echo form_error("sale_price"); ?></span>
        </div>
        <div class="form-group">
          <label for="product_weight">Product weight</label>
          <input type="text" class="form-control" id="product_weight" name="product_weight" value="<?php echo set_value("product_weight",$product->product_weight); ?>" placeholder="Product Weight">
          <span class="error"><?php echo form_error("product_weight"); ?></span>
        </div>
    
       <button type="submit" class="btn btn-default">Update</button>
        </div>
         
      <?php echo form_close(); ?>
      <?php }else{
	  		echo "No user exist";
	  }?>
    </div>
    <!-- /.col-sm-4 -->
    <div class="col-sm-2"> </div>
    <!-- /.col-sm-4 --> 
  </div>
  </div>
</div>
<?php include_once(APPPATH.'views/admin/_footer.php'); ?>
