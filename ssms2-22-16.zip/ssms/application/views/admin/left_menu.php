<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url("assets/admin/dist/img/asadullah.jpg") ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p>Asadullah Randhawa</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
          <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            
            
            
            <li class="treeview <?php echo ($controller_name == "dashboard")?'':'' ?>">
              <a href="#">
              <li class="active"><a href="<?php echo site_url("admin/dashboard/index"); ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </li></a>
              
            
            
            <li class="treeview <?php echo ($controller_name == "products")?'':'' ?>">
              <a href="#">
                <i class="fa fa-glass"></i> <span>Products</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
              <li class="active"><a href="<?php echo site_url("admin/products/add"); ?>">
              <i class="fa fa-circle-o"></i> Add</a></li>
                <li><a href="<?php echo site_url("admin/products/product_list"); ?>"><i class="fa fa-circle-o"></i> View All</a></li>
              </ul>
            </li>
            
            
            <li class="treeview <?php echo ($controller_name == "order")?'active':'' ?>">
              <a href="#">
                <i class="fa fa-shopping-cart"></i> <span>Order</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo site_url("admin/order/OrderProduction"); ?>">
                <i class="fa fa-circle-o"></i> Production Order</a></li>
                <li "><a href="<?php echo site_url("admin/order/OrderDelivery"); ?>">
                <i class="fa fa-circle-o"></i> Delivery Order</a></li>
                <li ><a href="<?php echo site_url("admin/order/detail"); ?>">
                <i class="fa fa-circle-o"></i> Order Detail </a>
               
                
                </li>
              </ul>
            </li>
            
            
            <li class="treeview <?php echo ($controller_name == "management")?'active':'' ?>">
              <a href="#">
                <i class="	fa fa-suitcase"></i> <span>OrderBooker Management</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="<?php echo site_url("admin/management/add"); ?>">
                <i class="fa   fa-circle-o"></i> Add OrderBooker</a></li>
                <li><a href="<?php echo site_url("admin/management/view"); ?>"><i class="fa fa-circle-o">
                </i> View OrderBookers</a>
                
                
                </li>
              </ul>
            </li>
            <li class="treeview <?php echo ($controller_name == "target")?'active':'' ?>">
              <a href="#">
                <i class="fa fa-tasks"></i></i> <span>OrderBooker Target</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="<?php echo site_url("admin/target/add_target"); ?>">
                <i class="fa   fa-circle-o"></i> Add Target</a></li>
                <li><a href="<?php echo site_url("admin/target/view_target"); ?>"><i class="fa fa-circle-o">
                </i> View Target</a>
                
                
                </li>
              </ul>
            </li>
            
            
        </section>
        <!-- /.sidebar -->
      </aside>