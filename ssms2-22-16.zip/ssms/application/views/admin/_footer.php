 <footer class="main-footer">
    
    <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo base_url(); ?>">SSMS</a>.</strong> All rights reserved. </footer>
  
  
</div>
<!-- ./wrapper --> 
</body>
</html>