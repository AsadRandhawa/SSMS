<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SignIn extends CI_Controller {
	public function lockscreen ()
	{
		$this->load->view('admin/SignIn/lock_screen');
		
	}	
	public function Sign ()
	{
		$this->load->view('admin/SignIn/Sign_in');
		
	}	
}
