<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Production extends CI_Controller {

	public function addOrder()
	{
		$this->load->view('productionManager/order/addOrder');
		
	}
	
	public function detail()
	{
		$this->load->view('productionManager/order/order_detail');
		
		
	}
}
