<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	public function addOrder()
	{
		$this->load->view('orderBooker/order/addOrder');
		
	}
	
	public function detail()
	{
		$this->load->view('orderBooker/order/order_detail');
		
		
	}
}
