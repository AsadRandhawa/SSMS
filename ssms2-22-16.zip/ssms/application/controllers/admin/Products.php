<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {
		
	public function __construct()
	{
			// Call the CI_Model constructor
			parent::__construct();
			$this->load->model('Product_model');
			
	}
	
	public function product_list()
	{
		
		$data['products'] = $this->Product_model->get_product();
		$this->load->view('admin/products/list',$data);
		
	}
		
	public function add (){
	
		$data = array();
		$data['message'] = "";
		
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
			$this->form_validation->set_rules('p_name', 'Product Name', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('p_cat', 'Product Category', 'required|max_length[100] ');
			$this->form_validation->set_rules('p_size', 'Product Size', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('p_image', 'Product Image');
			$this->form_validation->set_rules('prod_price', 'Production Price', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('sale_price', 'Sale Price', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('p_weight', 'Product Weight', 'required|max_length[100]|trim|alpha_numeric_spaces');

			
			if ($this->form_validation->run() != FALSE){
				$db_data = array();
				
				$res = $this->Product_model->check_product($this->input->post('p_name', TRUE),$this->input->post('p_size', TRUE));
				if(!isset($res->productID)){
						$db_data['product_name'] = $this->input->post('p_name', TRUE);
						$db_data['product_category'] = $this->input->post('p_cat', TRUE);
						$db_data['product_size'] = $this->input->post('p_size', TRUE);
						$db_data['production_price'] = $this->input->post('prod_price', TRUE);
						$db_data['sale_price'] = $this->input->post('sale_price', TRUE);
						$db_data['product_weight'] = $this->input->post('p_weight', TRUE);
						$db_data['product_image'] = $this->input->post('p_image', TRUE);
						
						$db_data['is_active'] = 1;
						$db_data['created_dtm'] = date("Y-m-d H:i:s");				
						
						//Configuration for image file
						$config = array();
						$config['upload_path']          = './uploads/';
						$config['allowed_types']        = 'gif|jpg|png|jpeg';
					  /*  $config['max_size']             = 1024;
						$config['max_width']            = 1024;
						$config['max_height']           = 768;
		*/				$config['encrypt_name']         = TRUE;
						
						
		
						$this->load->library('upload', $config);
		
						if ( ! $this->upload->do_upload('p_image')){
							$data['error'] =$this->upload->display_errors();
						}else{
							$upload_data = $this->upload->data();
							$db_data['product_image'] = $upload_data['file_name'];
							unset($upload_data);
							$this->Product_model->insert($db_data);
							
							
							$session_data = array(
									'is_added' => TRUE
							);
							
							$this->session->set_userdata($session_data);
							
							$this->session->set_flashdata('message', 'Thank you!');
							
							$data['message'] = "Record Added";
							redirect("admin/products/add");
						}
				}else{
					$data['error'] = "Product name and size already exist.";	
				}
			}else{
				$data['error'] = validation_errors();
			}
		}
		$this->load->view('admin/products/add',$data);
	}
	
 function edit($productID){
		$data = array();
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		
			
			
			$this->form_validation->set_rules('product_name', 'Product Name', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('product_category', 'Product Category', 'required|max_length[100] ');
			$this->form_validation->set_rules('product_size', 'Product Size', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('production_price', 'Production Price', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('sale_price', 'Sale Price', 'required|max_length[100]|trim|alpha_numeric_spaces');
			$this->form_validation->set_rules('product_weight', 'Product Weight', 'required|max_length[100]|trim|alpha_numeric_spaces');

			
			if ($this->form_validation->run() == TRUE)
			{
				
				$config = array();
				$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
				$config['encrypt_name']        = TRUE;
				
				
                
				
				$db_data = array();
                $this->load->library('upload', $config);
				
                if ($this->upload->do_upload('product_image'))
                {
                    $product = $this->Product_model->get_single_product($productID);
					if(file_exists("uploads/".$product->product_image)){
						unlink("uploads/".$product->product_image);
					}
					
					$db_data['product_image'] = $this->upload->data('file_name');
                }
				
				
				$db_data['product_name'] = $this->input->post('product_name', TRUE);
				$db_data['product_category'] = $this->input->post('product_category', TRUE);
				$db_data['product_size'] = $this->input->post('product_size', TRUE);
				$db_data['production_price'] = $this->input->post('production_price', TRUE);
				$db_data['sale_price'] = $this->input->post('sale_price', TRUE);
				$db_data['product_weight'] = $this->input->post('product_weight', TRUE);				
				$db_data['is_active'] = 1;
				$db_data['created_dtm'] = date("Y-m-d H:i:s");				
				  
				$this->Product_model->update($productID, $db_data);
					
					$session_data = array(
							'is_added' => TRUE
					);
					
					$this->session->set_userdata($session_data);
					
					$this->session->set_flashdata('message', 'Record Updated');
					
					$data['message'] = "Record Updated";
					
				redirect("admin/products/product_list");
			}
			
		}
		
		$data['product'] = $this->Product_model->get_single_product($productID);
		$this->load->view('admin/products/edit',$data);
	}
	
	function delete($productID){
		
		$product = $this->Product_model->get_single_product($productID);
		if(isset($product->productID)){
			if(file_exists("uploads/".$product->product_image)){
				unlink("uploads/".$product->product_image);
			}
			$this->Product_model->delete($productID);
			
			$this->session->set_flashdata('message', 'Record Deleted');
		}
		
		redirect("admin/products/product_list");
	}

}
