<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Target extends CI_Controller {

	public function view_target()
	{
		$this->load->view('admin/target/target_view');
		
	}
	public function add_target()
	{
		$this->load->view('admin/target/target_add');
		
		
	}
}
