<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Management extends CI_Controller {

	public function add()
	{
		$this->load->view('admin/management/add_user');
		
	}
	
	public function view()
	{
		$this->load->view('admin/management/view_all');
		
	}
	
}
