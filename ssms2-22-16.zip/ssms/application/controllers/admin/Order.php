<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	public function OrderProduction()
	{
		$this->load->view('admin/order/OrderProduction');

	}
	
	public function OrderDelivery()
	{
		$this->load->view('admin/order/OrderDelivery');

	}
	public function invoice()
	{
		$this->load->view('admin/order/invoice');
		
		
	}
	
	public function detail()
	{
		$this->load->view('admin/order/order_detail');
		
		
	}
}
