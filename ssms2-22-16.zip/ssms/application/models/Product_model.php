<?php
class Product_model extends CI_Model {
	public function __construct()
	{
			// Call the CI_Model constructor
			parent::__construct();
	}
	
	public function insert($data){
		$this->db->insert('products',$data);
	}
	
	public function get_product($limit = 0){
		if($limit == 0){
					return $this->get_all_products();
			}else{
				$this->db->select("productID,product_name,product_category,product_size,production_price,sale_price,product_weight");
				$this->db->limit($limit);
				return $this->db->get('products');
				/*return $this->db->select('user_id,user_name,father_name,email')
                ->limit($limit)
                ->get('users');*/
				
				//echo $this->db->last_query();exit;// will print query
			}
			
		}
		public function update($productID,$data){
			$this->db->where('productID', $productID);
			return $this->db->update('products', $data);
		}
		
		public function get_all_products(){
			//return $this->db->get('products');
			return $this->db->get_where('products', array('is_active' => '1'));
		}
		public function get_single_product($productID){
			return $this->db->select('*')
                ->where("productID",$productID)
				//->where("user_status",1)
				->limit(1)
                ->get('products')->row();
			//echo $this->db->last_query();exit;// will print query
		}
		function delete($productID){
	$data = array(
               'is_active' => 0
            );

$this->db->where('productID', $productID);
$this->db->update('products', $data); 

		}
		
		
		function check_product($name,$size){
			return $this->db->select('productID')
                ->where("product_name",$name)
				 ->where("product_size",$size)
				//->where("user_status",1)
				->limit(1)
                ->get('products')->row();
		}
	
	
/*	public function auth_user($data){
		$this->db->select('user_id,email');
		return $this->db->get_where('users',$data,1);
	} */
	
} ?>